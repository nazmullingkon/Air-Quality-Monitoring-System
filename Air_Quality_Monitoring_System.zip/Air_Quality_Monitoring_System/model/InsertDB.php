<?php
include("../controller/config.php");

	$ldrval=$_POST['id'];


   date_default_timezone_set("Asia/Dhaka");
    $d = date("Y-m-d");
	
    $t = date("H:i:s A");
	echo 'Hi..';

$sql = "INSERT INTO nodemcu_ldr_table (Ldr, Date, Time) VALUES ('$ldrval', '$d', '$t')"; 
$result=mysqli_query($myconn,$sql);
if($result===TRUE)
{
	echo 'Ok';
}
else
{
	echo "registration fail";
	}

?>
