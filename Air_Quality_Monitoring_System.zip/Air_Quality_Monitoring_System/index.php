<!DOCTYPE html>
<html lang="en">
<head>
  <title>Air Quality Monitoring System</title>
  <meta charset="utf-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
   <link href="css/styles.css" rel="stylesheet" />
  
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">

<nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">  
  <a class="navbar-brand" href="#section1">MONITORING</a>
  <div class="spinner-border text-white">Air</div>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="#section1">Home</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#section2">Scale</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#section3">Contact</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#section4">About-Us</a>
    </li>	
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        Region
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="ViewLdrValue.php">Link 1</a>
        <a class="dropdown-item" href="Kishoreganj/ViewLdrValue.php">Kishoreganj</a>
		<a class="dropdown-item" href="Puranthana/ViewLdrValue.php">Puran Thana</a>
      </div>
    </li>
  </ul>
</nav>



<div id="section1" class="main">
  <img src="img/various.jpg" alt="AirPollution" style="width:100%;">
  <div class="content">
    <h1 style="font-size:54px;" ><b>Air Quality Monitoring System</b></h1>
	<br>
    <p>IOT Based</p>
	 <button type="button" class="btn btn-warning btn-xl js-scroll-trigger" data-toggle="modal" data-target="#myModal" >
    MORE DETAILS
  </button>

  <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal body -->
        <div class="modal-body">
         <p style="color:black;">Real-Time Air Quality Monitoring System</p>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
  </div>
</div>



<div id="section2" class="container1" style="padding-top:70px;padding-bottom:70px;background:#85D0B9;height:450px;">
  <h4 style="text-align:center;">Air Quality PPM Scale</h4><br>
<hr class="divider light my-4" />
 <table style="color:white;width:90%;left:70px;position:absolute;font-family: Arial ;height:220px;">
 <tr style="background:#0D0D3E;"><th>Levels of Health Concern</th><th>Numerical Value(PPM)</th><th>Meaning</th></tr>
 <tr style="background:#207106;"><td>Good</td><td>0 to 500</td><td>Fresh air.Air quality is considered satisfactory.</td></tr>
 <tr style="background:#C6CB0B;"><td>Moderate</td><td>501 to 1000</td><td>Poor air.Air quality is acceptable. </td></tr>
 <tr style="background:#FF5733;"><td>Unhealthy for Sensitive Group</td><td>1001 to 1500</td><td>The general public is not likely to be affected.</td></tr>
 <tr style="background:#900C3F;"><td>Unhealthy</td><td>1501 to 2000</td><td>Members of sensitive group may experience more serious health effects.</td></tr>
 <tr style="background:#581845;"><td>Very Unhealthy</td><td>2001 to 2500</td><td>Health warning of emergency conditions.The entire polution is more likely to be affected.</td></tr>
 </table>
</div>
<div id="section3" class="contact" style="padding-top:70px;padding-bottom:70px;">
<h4 style="text-align:center;">Contact Us</h4><br>
<hr class="divider light my-4" />
  <div class="container">
  <div class="row">
    <div class="col-sm-4">
    <a href="https://twitter.com/LingkonNazmul" style="text-decoration:none;" ><i class="fa fa-twitter-square" style="font-size:48px;color:black"></i><p style="font-size:24px;color:black;font-family: Arial;">Nazmul Islam Lingkon</p></a>   
<a href="#" style="text-decoration:none;" ><i class="fa fa-twitter-square" style="font-size:48px;color:black"></i><p style="font-size:24px;color:black;font-family: Arial;">Sumya Zahan</p></a>  	
	 
    </div>
    <div class="col-sm-4">
      <a href="#" style="text-decoration:none;" ><i class="fa fa--square" style="font-size:48px;color:black">&#128231</i><p style="font-size:24px;color:black;font-family: Arial;">nazmulpae@gmail.com</p></a>
	  <a href="#" style="text-decoration:none;" ><i class="fa fa--square" style="font-size:48px;color:black">&#128231</i><p style="font-size:24px;color:black;font-family: Arial;">sumyapranto@gmail.com</p></a>
     
    </div>
    <div class="col-sm-4">
       <a href="#" style="text-decoration:none;" ><i class="fa fa-phone-square" style="font-size:48px;color:black"></i><p style="font-size:24px;color:black;font-family: Arial;">+8801782796150</p></a>        
       <a href="#" style="text-decoration:none;" ><i class="fa fa-phone-square" style="font-size:48px;color:black"></i><p style="font-size:24px;color:black;font-family: Arial;">+8801745482914</p></a>
    </div>
  </div>
 </div>
  </div>
  <div id="section4" class="container1" style="padding-top:70px;padding-bottom:70px;background:#9EC28A;height:400px;height:500px;">
  <h4 style="text-align:center;">About This Project</h4><br>
<hr class="divider light my-4" />
  <div class="container">
  <div class="row">
    <div class="col-sm-4" style="color:white;">
	<h4 >AIR QUALITY RESEARCH</h4><br>
	<li style="font-family: Arial ;">
	IOT Based Air Pollution Monitoring System.
	</li>
	<li style="font-family: Arial ;">
	We will monitor the Air Quality over a webserver using internet.
	</li>
	<li style="font-family: Arial ;">
	It will show the air quality in PPM.
	</li>	
	<li style="font-family: Arial ;">
	Able to measure harmful gases are present in the air like CO2, smoke, alcohol, benzene and NH3.
	</li>	
	<li style="font-family: Arial ;">
	We can install this system anywhere.
	</li>
	<li style="font-family: Arial ;">
	We can monitor it very easily.
	</li>
	</div>
	 
    <div class="col-sm-4" style="color:white;">
	 <img src="img/mq-135.jpg" alt="AirPollution" style="width:60%;left:65px;position:absolute;">
	 <br><br><br><br><br><br><br><br>
	 <p style="font-family: Arial;">We have used MQ135 sensor which is the best choice for monitoring Air Quality as it can detects most harmful gases and can measure their amount accurately.</p>
	</div>
	 
    <div class="col-sm-4" style="color:white;">
	<img src="img/NodeMCU.png" alt="AirPollution" style="width:60%;left:65px;position:absolute;">
	 <br><br><br><br><br><br><br><br>
	 <p style="font-family: Arial;">NodeMCU V3 is an open-source firmware and development kit that plays a vital role in designing a proper IoT product using a few script lines.The module is mainly  based  on ESP8266.</p>
	</div>
	</div>
	</div>
	
	
</div>
  


<div class="footer" ><br>
<p style="font-size:28px;color:white;">Thank You</p>
</div>


</body>
</html>
