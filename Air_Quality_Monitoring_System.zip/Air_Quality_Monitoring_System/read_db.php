<!DOCTYPE html>
<html>
	<head>
	
	  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
   <link href="css/styles.css" rel="stylesheet" />
		<style>
			table {
				border-collapse: collapse;
				width: 100%;
				color: #1f5380;
				font-family: monospace;
				font-size: 20px;
				text-align: left;
			} 
			th {
				background-color: #1f5380;
				color: white;
			}
			tr:nth-child(even) {background-color: #f2f2f2}
			.main{
				text-align:center;
				color:white;
				background-color:#1f5380;
			}
		</style>
	</head>

	
	<?php
		
		$hostname = "localhost";		
		$username = "root";		
		$password = "";	
		$dbname = "nodemcu_ldr";
		
		$conn = mysqli_connect($hostname, $username, $password, $dbname);
		
		if (!$conn) {
			die("Connection failed !!!");
		} 
	?>
	<body>
	
	<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand/logo -->
<a class="navbar-brand" href="#section1">MONITORING</a>
  <div class="spinner-border text-white">Air</div>
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="index.php#section1"><b>Home</b></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="index.php#section2"><b>Scale</b></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="index.php#section3"><b>Contact</b></a>
    </li>
	    <li class="nav-item">
      <a class="nav-link" href="index.php#section4"><b>About-Us</b></a>
    </li>
	    
	<li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
       <b>  Region</b>
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="read_db.php">Link 1</a>
        <a class="dropdown-item" href="#"><b>Link2</b></a>
     
		</div>

  </ul>

</nav>

	<div class="main"><br>
	<h1>Real Time Monitoring System</h1>
	<marquee>
	<h2>
	
	<?php
$mysqli = new mysqli("localhost","root","","nodemcu_ldr");

if ($mysqli -> connect_errno) {
  echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  exit();
}


$sql = "SELECT * FROM nodemcu_ldr_table ORDER BY No DESC LIMIT 1 " ;

if ($result = $mysqli -> query($sql)) {
  while ($row = $result -> fetch_row()) {
    printf ("Serial Number %s Air Quality =%s\nPPM /Date:%s/Time:%s", $row[0], $row[1],$row[2],$row[3]);
  }
  $result -> free_result();
}

$mysqli -> close();


?>
</h2>
</marquee>

</div>
<br>
	
		<table>
			<tr>
				<th>No</th> 
				<th>MQ Value</th> 
				<th>Date</th>
				<th>Time</th>
			</tr>	
			<?php
				$table = mysqli_query($conn, "SELECT No, Ldr, Date, Time FROM nodemcu_ldr_table"); 
				while($row = mysqli_fetch_array($table))
				{
			?>
			<tr>
				<td><?php echo $row["No"]; ?></td>
				<td><?php echo $row["Ldr"]; ?></td>
				<td><?php echo $row["Date"]; ?></td>
				<td><?php echo $row["Time"]; ?></td>
			</tr>
			<?php
				}
			?>
		</table>
	</body>
</html>