<!DOCTYPE html>
<html>
	<head>
	  
		

		<style>
			table {
				border-collapse: collapse;
				width: 100%;
				color: #1f5380;
				font-family: monospace;
				font-size: 20px;
				text-align: center;
			} 
			th {
				background-color: #1f5380;
				color: white;
			}
			tr:nth-child(even) {background-color: #f2f2f2}
			.main{
				text-align:center;
				color:#5F8549;
				background-color:#071918;
				font-family: Arial Black;
			}
		</style>
	</head>

	
	<?php
		
		$hostname = "localhost";		
		$username = "root";		
		$password = "";	
		$dbname = "nodemcu_ldr";
		
		$conn = mysqli_connect($hostname, $username, $password, $dbname);
		
		if (!$conn) {
			die("Connection failed !!!");
		} 
	?>
	<body>
	<div class="main"><br>
	<h1>Real Time Monitoring System</h1>
	
	
	<h2>
	<?php
$mysqli = new mysqli("localhost","root","","nodemcu_ldr");

if ($mysqli -> connect_errno) {
  echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  exit();
}


$sql = "SELECT * FROM kishoreganj ORDER BY No DESC LIMIT 1 " ;

if ($result = $mysqli -> query($sql)) {
  while ($row = $result -> fetch_row()) {
    printf ("(%s) Air Quality =%s\nPPM /Date:%s/Time:%s", $row[0], $row[1],$row[2],$row[3]);
	
  }
  $result -> free_result();
}

$mysqli -> close();


?>
</h2>
<br>
</div>

		<table>
			<tr>
				<th>No</th> 
				<th>MQ Value</th> 
				<th>Date</th>
				<th>Time</th>
			</tr>	
			<?php
				$table = mysqli_query($conn, "SELECT No, Ldr, Date, Time FROM kishoreganj"); 
				while($row = mysqli_fetch_array($table))
				{
			?>
			<tr>
				<td><?php echo $row["No"]; ?></td>
				<td><?php echo $row["Ldr"]; ?></td>
				<td><?php echo $row["Date"]; ?></td>
				<td><?php echo $row["Time"]; ?></td>
			</tr>
			<?php
				}
			?>
		</table>
		
	</body>
</html>