<!DOCTYPE html>
<html>
	<head>
	
		<title>Air Quality Monitoring System</title>
		<meta charset="utf-8">
		
		<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
   <link href="css/styles.css" rel="stylesheet" />
		
		<script src="jquery.min.js"></script>
		<script>
			$(document).ready(function() {
				setInterval(function(){get_data()},5000);
				function get_data()
				{
					jQuery.ajax({
						type:"GET",
						url: "read_db.php",
						data:"",
						beforeSend: function() {
						},
						complete: function() {
						},
						success:function(data) {
							$("table").html(data);
						}
					});
				}
			});
		</script>
		<style>
			table {
				border-collapse: collapse;
				width: 100%;
				color: #1f5380;
				font-family: monospace;
				font-size: 20px;
				text-align: center;
			} 
			th {
				background-color: #1f5380;
				color: white;
			}
			tr:nth-child(even) {background-color: #f2f2f2}
			
		</style>
	</head>
	<body>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">

<a class="navbar-brand" href="#section1">MONITORING</a>
  <div class="spinner-border text-white">Air</div>

  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="../index.php#section1"><b>Home</b></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="../index.php#section2"><b>Scale</b></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="../index.php#section3"><b>Contact</b></a>
    </li>
	    <li class="nav-item">
      <a class="nav-link" href="../index.php#section4"><b>About-Us</b></a>
    </li>
	    
	<li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
       <b>  Region</b>
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="../ViewLdrValue.php">Link 1</a>
        <a class="dropdown-item" href="../Kishoreganj/ViewLdrValue.php">Kishoreganj</a>
		<a class="dropdown-item" href="../Puranthana/ViewLdrValue.php">Puran Thana</a>
     
		</div>

  </ul>

</nav>


	
<div>

		<table>
			<tr>
				<th>No</th> 
				<th>MQ Value</th> 
				<th>Date</th>
				<th>Time</th>
			</tr>
		</table>
		</div>
	</body>
</html>